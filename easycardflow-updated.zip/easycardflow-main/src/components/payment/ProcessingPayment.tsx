
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { LoaderCircle, Check, AlertCircle, CreditCard } from "lucide-react";
import { usePayment } from "@/contexts/PaymentContext";
import { useDevice } from "@/contexts/DeviceContext";
import { Button } from "@/components/ui/button";

interface ProcessingPaymentProps {
  onComplete?: () => void;
}

export function ProcessingPayment({ onComplete }: ProcessingPaymentProps) {
  const { amount, addTransaction, formatAmount } = usePayment();
  const { activeReader } = useDevice();
  const navigate = useNavigate();
  
  const [stage, setStage] = useState<"connecting" | "awaiting-card" | "processing" | "pin" | "successful" | "failed">("connecting");
  const [pinDigits, setPinDigits] = useState<string[]>(["", "", "", ""]);
  const [currentPinIndex, setCurrentPinIndex] = useState(0);
  const [errorMessage, setErrorMessage] = useState("");
  
  useEffect(() => {
    // Simulate connecting to card reader
    const timer = setTimeout(() => {
      if (!activeReader) {
        setStage("failed");
        setErrorMessage("No card reader connected. Please connect a reader in the profile section.");
        return;
      }
      
      setStage("awaiting-card");
      
      // Simulate awaiting card
      const cardTimer = setTimeout(() => {
        setStage("processing");
        
        // Simulate processing
        const processTimer = setTimeout(() => {
          setStage("pin");
        }, 2000);
        
        return () => clearTimeout(processTimer);
      }, 3000);
      
      return () => clearTimeout(cardTimer);
    }, 2000);
    
    return () => clearTimeout(timer);
  }, [activeReader]);
  
  const handlePinDigit = (digit: number) => {
    if (currentPinIndex >= 4) return;
    
    const newPinDigits = [...pinDigits];
    newPinDigits[currentPinIndex] = digit.toString();
    setPinDigits(newPinDigits);
    setCurrentPinIndex(prev => prev + 1);
    
    // If we've entered all 4 digits, simulate processing
    if (currentPinIndex === 3) {
      setTimeout(() => {
        // 10% chance of failure for demo purposes
        const success = Math.random() > 0.1;
        
        if (success) {
          setStage("successful");
          
          const numAmount = parseFloat(amount) || 0;
          const transaction = addTransaction({
            amount: numAmount,
            status: "completed",
            cardType: "Visa",
            cardLast4: "4321",
            receiptSent: false
          });
          
          // Navigate to receipt page after a delay
          setTimeout(() => {
            if (onComplete) {
              onComplete();
            } else {
              navigate(`/receipt/${transaction.id}`);
            }
          }, 2000);
          
        } else {
          setStage("failed");
          setErrorMessage("Transaction declined by bank. Please try another card.");
        }
      }, 2000);
    }
  };
  
  const resetPin = () => {
    setPinDigits(["", "", "", ""]);
    setCurrentPinIndex(0);
  };
  
  const retryTransaction = () => {
    setStage("connecting");
    setErrorMessage("");
    resetPin();
  };
  
  const renderStageContent = () => {
    switch (stage) {
      case "connecting":
        return (
          <div className="flex flex-col items-center">
            <LoaderCircle className="h-16 w-16 text-primary animate-spin mb-4" />
            <h2 className="text-xl font-medium mb-2">Connecting to Card Reader</h2>
            <p className="text-muted-foreground">Please wait while we connect to your card reader</p>
          </div>
        );
        
      case "awaiting-card":
        return (
          <div className="flex flex-col items-center">
            <CreditCard className="h-16 w-16 text-primary animate-pulse mb-4" />
            <h2 className="text-xl font-medium mb-2">Insert or Tap Card</h2>
            <p className="text-muted-foreground">Please insert or tap customer's card to proceed</p>
            <div className="mt-8 w-full max-w-xs">
              <div className="text-center text-sm text-muted-foreground mb-2">Amount</div>
              <div className="text-3xl font-medium text-center">₦{formatAmount(amount)}</div>
            </div>
          </div>
        );
        
      case "processing":
        return (
          <div className="flex flex-col items-center">
            <LoaderCircle className="h-16 w-16 text-primary animate-spin mb-4" />
            <h2 className="text-xl font-medium mb-2">Processing Card</h2>
            <p className="text-muted-foreground">Please don't remove the card</p>
          </div>
        );
        
      case "pin":
        return (
          <div className="flex flex-col items-center">
            <h2 className="text-xl font-medium mb-6">Enter PIN</h2>
            <p className="text-muted-foreground mb-6">Ask customer to enter their card PIN</p>
            
            <div className="flex gap-3 mb-8">
              {pinDigits.map((digit, index) => (
                <div
                  key={index}
                  className="w-10 h-10 rounded-full border-2 border-primary flex items-center justify-center"
                >
                  {digit ? "•" : ""}
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-3 gap-3 w-full max-w-xs">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                <button
                  key={num}
                  className="w-16 h-16 rounded-md bg-secondary hover:bg-secondary/80 flex items-center justify-center text-xl font-medium transition-colors"
                  onClick={() => handlePinDigit(num)}
                >
                  {num}
                </button>
              ))}
              <button
                className="w-16 h-16 rounded-md bg-destructive/10 hover:bg-destructive/20 text-destructive flex items-center justify-center text-lg font-medium transition-colors"
                onClick={resetPin}
              >
                Clear
              </button>
              <button
                className="w-16 h-16 rounded-md bg-secondary hover:bg-secondary/80 flex items-center justify-center text-xl font-medium transition-colors"
                onClick={() => handlePinDigit(0)}
              >
                0
              </button>
              <div className="w-16 h-16"></div>
            </div>
          </div>
        );
        
      case "successful":
        return (
          <div className="flex flex-col items-center">
            <div className="rounded-full bg-success/20 p-4 mb-4">
              <Check className="h-12 w-12 text-success" />
            </div>
            <h2 className="text-xl font-medium mb-2">Payment Successful</h2>
            <p className="text-muted-foreground mb-4">Transaction has been completed successfully</p>
            <div className="text-3xl font-medium mb-6">₦{formatAmount(amount)}</div>
          </div>
        );
        
      case "failed":
        return (
          <div className="flex flex-col items-center">
            <div className="rounded-full bg-destructive/20 p-4 mb-4">
              <AlertCircle className="h-12 w-12 text-destructive" />
            </div>
            <h2 className="text-xl font-medium mb-2">Payment Failed</h2>
            <p className="text-center text-muted-foreground mb-6">{errorMessage}</p>
            <Button onClick={retryTransaction}>Retry Transaction</Button>
          </div>
        );
    }
  };
  
  return (
    <div className="flex flex-col items-center justify-center p-6 h-full">
      {renderStageContent()}
    </div>
  );
}

export default ProcessingPayment;
