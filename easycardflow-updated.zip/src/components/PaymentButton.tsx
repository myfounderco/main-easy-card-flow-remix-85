import React from "react";
import axios from "axios";

const PaymentButton: React.FC = () => {
  const handlePayment = async () => {
    try {
      const response = await axios.post("/api/paystack/initiate", {
        email: "customer@example.com",
        amount: 5000, // Amount in Naira
      });
      const { data } = response.data;
      window.location.href = data.authorization_url;
    } catch (error) {
      console.error("Payment initialization error:", error);
    }
  };

  return <button onClick={handlePayment}>Pay with Paystack</button>;
};

export default PaymentButton;
