import { Module } from '@nestjs/common';
import { AdminModule } from '@adminjs/nestjs';
import AdminJS from 'adminjs';
import * as AdminJSExpress from '@adminjs/express';
import * as TypeOrmAdapter from '@adminjs/typeorm';
import { DataSource } from 'typeorm';
import { User } from '../entities/user.entity';
import { Payment } from '../entities/payment.entity';

AdminJS.registerAdapter(TypeOrmAdapter);

@Module({
  imports: [
    AdminModule.createAdminAsync({
      useFactory: async (dataSource: DataSource) => {
        return {
          adminJsOptions: {
            rootPath: '/admin',
            resources: [User, Payment],
          },
          auth: {
            authenticate: async (email, password) => {
              if (email === 'admin@example.com' && password === 'securepassword') {
                return { email };
              }
              return null;
            },
            cookieName: 'adminjs',
            cookiePassword: 'complexsecret',
          },
          sessionOptions: {
            secret: 'complexsecret',
            resave: false,
            saveUninitialized: true,
          },
        };
      },
      inject: [DataSource],
    }),
  ],
})
export class AdminPanelModule {}
