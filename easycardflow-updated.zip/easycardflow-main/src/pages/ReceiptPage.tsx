
import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Printer, Share } from "lucide-react";
import { Button } from "@/components/ui/button";
import { usePayment } from "@/contexts/PaymentContext";
import { ReceiptForm } from "@/components/payment/ReceiptForm";
import { toast } from "sonner";

const ReceiptPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { transactions } = usePayment();
  
  const transaction = id ? transactions.find(t => t.id === id) : null;
  
  const handleGoBack = () => {
    navigate("/history");
  };
  
  const handlePrint = () => {
    toast.info("Print functionality would be connected to a receipt printer");
  };
  
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `Receipt #${id}`,
        text: `Transaction receipt for ₦${transaction?.amount.toFixed(2)}`,
      }).catch((error) => {
        toast.error("Error sharing receipt");
      });
    } else {
      toast.info("Sharing not supported on this device");
    }
  };
  
  if (!transaction) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <div className="p-4 border-b border-border">
          <Button variant="ghost" size="icon" onClick={handleGoBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-medium mb-2">Receipt Not Found</h2>
            <p className="text-muted-foreground mb-4">The receipt you're looking for doesn't exist.</p>
            <Button onClick={handleGoBack}>Go Back</Button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <Button variant="ghost" size="icon" onClick={handleGoBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        
        <h1 className="text-lg font-medium">Receipt</h1>
        
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={handlePrint}>
            <Printer className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={handleShare}>
            <Share className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      <div className="flex-1 p-6">
        <div className="max-w-md mx-auto">
          <div className="flex flex-col items-center mb-8">
            <div className="h-16 w-16 rounded-full bg-success/10 flex items-center justify-center mb-4">
              <span className="text-success text-2xl">₦</span>
            </div>
            <h2 className="text-3xl font-medium mb-1">₦{transaction.amount.toFixed(2)}</h2>
            <p className="text-muted-foreground">
              {transaction.date.toLocaleDateString()} at {transaction.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
          
          <ReceiptForm transactionId={transaction.id} />
        </div>
      </div>
    </div>
  );
};

export default ReceiptPage;
