
import React, { useState } from "react";
import { Check, Copy, Send } from "lucide-react";
import { toast } from "sonner";
import { usePayment } from "@/contexts/PaymentContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface ReceiptFormProps {
  transactionId: string;
}

export function ReceiptForm({ transactionId }: ReceiptFormProps) {
  const { transactions, sendReceipt } = usePayment();
  const [email, setEmail] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const transaction = transactions.find(t => t.id === transactionId);
  
  if (!transaction) {
    return <div>Transaction not found</div>;
  }
  
  const handleSendReceipt = async () => {
    if (!email || !email.includes("@")) {
      toast.error("Please enter a valid email address");
      return;
    }
    
    setIsSending(true);
    try {
      await sendReceipt(transactionId, email);
      setEmail("");
    } catch (error) {
      toast.error("Failed to send receipt. Please try again.");
    } finally {
      setIsSending(false);
    }
  };
  
  const copyReceiptToClipboard = () => {
    const receiptText = `
      Receipt #${transaction.id}
      Date: ${transaction.date.toLocaleString()}
      Amount: ₦${transaction.amount.toFixed(2)}
      Status: ${transaction.status}
      Card: ${transaction.cardType} ****${transaction.cardLast4}
    `;
    
    navigator.clipboard.writeText(receiptText.trim());
    setCopied(true);
    toast.success("Receipt copied to clipboard");
    
    setTimeout(() => setCopied(false), 2000);
  };
  
  return (
    <div className="space-y-4 w-full">
      <div className="p-4 bg-secondary/50 rounded-lg space-y-3">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Receipt #</span>
          <span className="font-mono">{transaction.id}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Date</span>
          <span>{transaction.date.toLocaleString()}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Amount</span>
          <span className="font-medium">₦{transaction.amount.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Status</span>
          <span className="capitalize">{transaction.status}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Payment Method</span>
          <span>{transaction.cardType} ****{transaction.cardLast4}</span>
        </div>
      </div>
      
      <div className="flex justify-end">
        <Button
          variant="outline"
          size="sm"
          className="flex items-center gap-1.5"
          onClick={copyReceiptToClipboard}
        >
          {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          {copied ? "Copied" : "Copy Receipt"}
        </Button>
      </div>
      
      <div className="pt-4 border-t border-border">
        <h3 className="text-lg font-medium mb-2">Send Receipt</h3>
        <div className="flex gap-2">
          <Input
            type="email"
            placeholder="Customer's email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Button
            onClick={handleSendReceipt}
            disabled={isSending}
            className="shrink-0"
          >
            {isSending ? (
              "Sending..."
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Send
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default ReceiptForm;
