
import React, { useState } from "react";
import { useDevice } from "@/contexts/DeviceContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export function BankAccountForm() {
  const { addBankAccount } = useDevice();
  
  const [bankName, setBankName] = useState("");
  const [accountName, setAccountName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [isDefault, setIsDefault] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!bankName || !accountName || !accountNumber) {
      return;
    }
    
    addBankAccount({
      bankName,
      accountName,
      accountNumber,
      isDefault
    });
    
    // Reset form
    setBankName("");
    setAccountName("");
    setAccountNumber("");
    setIsDefault(false);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="bankName">Bank Name</Label>
        <Input 
          id="bankName"
          value={bankName}
          onChange={(e) => setBankName(e.target.value)}
          placeholder="Enter bank name"
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="accountName">Account Name</Label>
        <Input 
          id="accountName"
          value={accountName}
          onChange={(e) => setAccountName(e.target.value)}
          placeholder="Enter account name"
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="accountNumber">Account Number</Label>
        <Input 
          id="accountNumber"
          value={accountNumber}
          onChange={(e) => setAccountNumber(e.target.value)}
          placeholder="Enter account number"
          maxLength={10}
          minLength={10}
          required
        />
      </div>
      
      <div className="flex items-center space-x-2">
        <Switch 
          id="isDefault" 
          checked={isDefault}
          onCheckedChange={setIsDefault}
        />
        <Label htmlFor="isDefault">Set as default account</Label>
      </div>
      
      <Button type="submit" className="w-full">Add Bank Account</Button>
    </form>
  );
}

export default BankAccountForm;
