
import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const GetStartedPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="relative h-screen w-full overflow-hidden bg-gradient-to-b from-background/90 to-background">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/lovable-uploads/5937222e-3199-40d5-baef-7066b63c41f2.png"
          alt="Credit card reader connected to iPhone"
          className="h-full w-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <div className="relative z-10 flex h-full flex-col items-center justify-between px-6 py-20">
        <div className="text-center">
          <h1 className="mb-2 text-4xl font-bold text-white md:text-5xl">
            EasyCardFlow
          </h1>
          <p className="text-xl text-white/90">
            Accept payments anywhere, anytime
          </p>
        </div>

        <div className="flex w-full max-w-md flex-col items-center space-y-8">
          <div className="rounded-lg bg-white/10 p-6 backdrop-blur-lg">
            <h2 className="mb-4 text-center text-2xl font-semibold text-white">
              Get Started
            </h2>
            <p className="text-center text-white/90">
              Connect your card reader and start accepting payments in minutes.
            </p>
          </div>

          <Button
            onClick={() => navigate("/login")}
            className="w-full gap-2 bg-payment-blue py-6 text-lg font-medium text-white hover:bg-payment-darkBlue"
          >
            Next
            <ArrowRight className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default GetStartedPage;
