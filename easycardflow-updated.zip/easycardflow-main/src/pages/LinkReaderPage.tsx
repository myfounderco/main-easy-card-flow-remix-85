
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Bluetooth, Search, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useDevice } from "@/contexts/DeviceContext";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface DiscoveredReader {
  id: string;
  name: string;
  signal: number; // 0-100
}

const LinkReaderPage = () => {
  const navigate = useNavigate();
  const { addReader, connectReader } = useDevice();
  
  const [isScanning, setIsScanning] = useState(false);
  const [selectedReader, setSelectedReader] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [discoveredReaders, setDiscoveredReaders] = useState<DiscoveredReader[]>([]);
  
  useEffect(() => {
    // Start scanning automatically when the page loads
    handleStartScan();
  }, []);
  
  const handleGoBack = () => {
    navigate(-1);
  };
  
  const handleStartScan = () => {
    setIsScanning(true);
    setDiscoveredReaders([]);
    
    // Simulate discovering readers
    const scanTimeout = setTimeout(() => {
      const mockReaders: DiscoveredReader[] = [
        {
          id: `reader-${Date.now().toString(36)}-1`,
          name: "Square Reader S1",
          signal: 87
        },
        {
          id: `reader-${Date.now().toString(36)}-2`,
          name: "PayPal Reader",
          signal: 65
        },
        {
          id: `reader-${Date.now().toString(36)}-3`,
          name: "SumUp Air",
          signal: 92
        }
      ];
      
      setDiscoveredReaders(mockReaders);
      setIsScanning(false);
    }, 3000);
    
    return () => clearTimeout(scanTimeout);
  };
  
  const handleSelectReader = (readerId: string) => {
    setSelectedReader(readerId);
  };
  
  const handleConnectReader = async () => {
    if (!selectedReader) return;
    
    const reader = discoveredReaders.find(r => r.id === selectedReader);
    if (!reader) return;
    
    setIsConnecting(true);
    
    try {
      const newReader = addReader({
        name: reader.name,
        batteryLevel: 100,
      });
      
      await connectReader(newReader.id);
      
      toast.success(`Successfully connected to ${reader.name}`);
      navigate("/profile");
    } catch (error) {
      toast.error("Failed to connect to reader. Please try again.");
    } finally {
      setIsConnecting(false);
    }
  };
  
  const getSignalStrengthLabel = (signal: number) => {
    if (signal >= 80) return "Excellent";
    if (signal >= 60) return "Good";
    if (signal >= 40) return "Fair";
    return "Poor";
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className="p-4 border-b border-border flex items-center">
        <Button variant="ghost" size="icon" onClick={handleGoBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-lg font-medium ml-2">Link Card Reader</h1>
      </div>
      
      <div className="flex-1 p-6">
        <div className="mb-8">
          <h2 className="text-xl font-medium mb-3">Available Readers</h2>
          <p className="text-muted-foreground mb-6">
            Make sure your card reader is turned on and in pairing mode.
          </p>
          
          <Button
            variant="outline"
            className="w-full flex items-center justify-center"
            onClick={handleStartScan}
            disabled={isScanning}
          >
            {isScanning ? (
              <>
                <Search className="h-4 w-4 mr-2 animate-spin" />
                Scanning...
              </>
            ) : (
              <>
                <Search className="h-4 w-4 mr-2" />
                Scan for Readers
              </>
            )}
          </Button>
        </div>
        
        {isScanning ? (
          <div className="flex flex-col items-center justify-center py-12">
            <div className="relative">
              <Bluetooth className="h-10 w-10 text-primary" />
              <div className="absolute inset-0 border-2 border-primary/20 animate-ping rounded-full"></div>
              <div className="absolute inset-0 border-2 border-primary/40 animate-ping rounded-full animation-delay-300"></div>
            </div>
            <p className="mt-4 text-muted-foreground">Searching for nearby card readers...</p>
          </div>
        ) : (
          <>
            {discoveredReaders.length === 0 ? (
              <div className="text-center py-10">
                <Bluetooth className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Readers Found</h3>
                <p className="text-muted-foreground mb-4">Make sure your reader is powered on and in pairing mode.</p>
                <Button onClick={handleStartScan}>Try Again</Button>
              </div>
            ) : (
              <div className="space-y-4">
                {discoveredReaders.map((reader) => (
                  <div
                    key={reader.id}
                    className={cn(
                      "p-4 border rounded-lg transition-all duration-200 cursor-pointer",
                      selectedReader === reader.id 
                        ? "border-primary bg-primary/5" 
                        : "border-border hover:border-primary/50"
                    )}
                    onClick={() => handleSelectReader(reader.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Bluetooth className="h-5 w-5 text-primary mr-3" />
                        <div>
                          <h3 className="font-medium">{reader.name}</h3>
                          <p className="text-xs text-muted-foreground">
                            Signal: {getSignalStrengthLabel(reader.signal)}
                          </p>
                        </div>
                      </div>
                      
                      {selectedReader === reader.id && (
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center">
                          <Check className="h-3 w-3 text-white" />
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                
                <Button
                  className="w-full mt-6"
                  disabled={!selectedReader || isConnecting}
                  onClick={handleConnectReader}
                >
                  {isConnecting ? "Connecting..." : "Connect Reader"}
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default LinkReaderPage;
