
import React from "react";
import { X } from "lucide-react";
import { usePayment } from "@/contexts/PaymentContext";

export function Keypad() {
  const { addDigit, clearAmount } = usePayment();
  
  const handleKeyPress = (digit: string) => {
    addDigit(digit);
  };
  
  const handleClear = () => {
    clearAmount();
  };
  
  return (
    <div className="w-full grid grid-cols-3 gap-2">
      {/* Row 1 */}
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("1")}
      >
        1
      </button>
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("2")}
      >
        2
      </button>
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("3")}
      >
        3
      </button>
      
      {/* Row 2 */}
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("4")}
      >
        4
      </button>
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("5")}
      >
        5
      </button>
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("6")}
      >
        6
      </button>
      
      {/* Row 3 */}
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("7")}
      >
        7
      </button>
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("8")}
      >
        8
      </button>
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("9")}
      >
        9
      </button>
      
      {/* Row 4 */}
      <button 
        className="keypad-clear"
        onClick={handleClear}
      >
        Clear
      </button>
      <button 
        className="keypad-button"
        onClick={() => handleKeyPress("0")}
      >
        0
      </button>
      <button 
        className="keypad-action"
        onClick={() => handleKeyPress(".")}
      >
        .
      </button>
    </div>
  );
}

export default Keypad;
