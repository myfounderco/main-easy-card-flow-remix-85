import { ResourceWithOptions } from 'adminjs';
import { User } from '../entities/user.entity';

export const UserResource: ResourceWithOptions = {
  resource: User,
  options: {
    properties: {
      password: { isVisible: { list: false, edit: true, show: false, filter: false } },
      role: {
        availableValues: [
          { value: 'admin', label: 'Admin' },
          { value: 'manager', label: 'Manager' },
          { value: 'support', label: 'Support' },
        ],
      },
    },
    actions: {
      edit: {
        isAccessible: ({ currentAdmin }) => currentAdmin && currentAdmin.role === 'admin',
      },
      delete: {
        isAccessible: ({ currentAdmin }) => currentAdmin && currentAdmin.role === 'admin',
      },
      new: {
        isAccessible: ({ currentAdmin }) => currentAdmin && currentAdmin.role === 'admin',
      },
      list: {
        isAccessible: ({ currentAdmin }) => currentAdmin && (currentAdmin.role === 'admin' || currentAdmin.role === 'manager'),
      },
    },
  },
};
