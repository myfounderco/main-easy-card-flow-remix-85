
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { PaymentProvider } from "./contexts/PaymentContext";
import { DeviceProvider } from "./contexts/DeviceContext";

import GetStartedPage from "./pages/GetStartedPage";
import LoginPage from "./pages/LoginPage";
import KeypadPage from "./pages/KeypadPage";
import HistoryPage from "./pages/HistoryPage";
import ProfilePage from "./pages/ProfilePage";
import ReceiptPage from "./pages/ReceiptPage";
import ProcessPaymentPage from "./pages/ProcessPaymentPage";
import LinkReaderPage from "./pages/LinkReaderPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <PaymentProvider>
      <DeviceProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/get-started" element={<GetStartedPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/" element={<KeypadPage />} />
              <Route path="/history" element={<HistoryPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/receipt/:id" element={<ReceiptPage />} />
              <Route path="/process-payment" element={<ProcessPaymentPage />} />
              <Route path="/link-reader" element={<LinkReaderPage />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </DeviceProvider>
    </PaymentProvider>
  </QueryClientProvider>
);

export default App;
