
import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProcessingPayment } from "@/components/payment/ProcessingPayment";

const ProcessPaymentPage = () => {
  const navigate = useNavigate();
  
  const handleCancel = () => {
    navigate(-1);
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className="p-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={handleCancel}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
      </div>
      
      <div className="flex-1 flex items-center justify-center">
        <ProcessingPayment />
      </div>
    </div>
  );
};

export default ProcessPaymentPage;
