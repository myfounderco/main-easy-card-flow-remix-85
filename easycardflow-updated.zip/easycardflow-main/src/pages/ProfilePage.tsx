
import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CreditCard, Wallet, ChevronRight, UserCircle } from "lucide-react";
import { useDevice } from "@/contexts/DeviceContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BottomNav } from "@/components/layout/BottomNav";
import { BankAccountForm } from "@/components/profile/BankAccountForm";
import { BankAccountList } from "@/components/profile/BankAccountList";
import { CardReaderList } from "@/components/devices/CardReaderList";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const ProfilePage = () => {
  const { readers, bankAccounts } = useDevice();
  const [activeTab, setActiveTab] = useState("account");
  
  return (
    <div className="min-h-screen flex flex-col pb-16 bg-background">
      <div className="p-4 border-b border-border">
        <h1 className="text-2xl font-medium">My Account</h1>
      </div>
      
      <div className="p-4 pb-8">
        <Card className="mb-6 bg-gradient-to-br from-primary/5 to-primary/20 border-primary/20">
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
                <UserCircle className="h-6 w-6 text-primary" />
              </div>
              <div className="ml-4">
                <h2 className="font-medium">Business Account</h2>
                <p className="text-sm text-muted-foreground">John's Hardware Store</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="devices">Devices</TabsTrigger>
          </TabsList>
          
          <TabsContent value="account" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Wallet className="h-5 w-5 mr-2" />
                  Bank Accounts
                </CardTitle>
                <CardDescription>
                  Add your bank accounts for deposits
                </CardDescription>
              </CardHeader>
              <CardContent>
                <BankAccountList />
                
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="w-full mt-4">
                      Add Bank Account
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Bank Account</DialogTitle>
                    </DialogHeader>
                    <BankAccountForm />
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Settings</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  <div className="flex items-center justify-between py-3 px-6 hover:bg-muted/50 cursor-pointer">
                    <span>Business Profile</span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex items-center justify-between py-3 px-6 hover:bg-muted/50 cursor-pointer">
                    <span>Notifications</span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex items-center justify-between py-3 px-6 hover:bg-muted/50 cursor-pointer">
                    <span>Security</span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex items-center justify-between py-3 px-6 hover:bg-muted/50 cursor-pointer">
                    <span>Help & Support</span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="devices" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="h-5 w-5 mr-2" />
                  Card Readers
                </CardTitle>
                <CardDescription>
                  Manage your connected card readers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <CardReaderList />
                
                <Button
                  variant="outline"
                  className="w-full mt-4"
                  onClick={() => window.location.href = '/link-reader'}
                >
                  Add New Reader
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      <BottomNav />
    </div>
  );
};

export default ProfilePage;
