
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { usePayment } from "@/contexts/PaymentContext";
import { useDevice } from "@/contexts/DeviceContext";
import { Button } from "@/components/ui/button";
import { Keypad } from "@/components/keypad/Keypad";
import { BottomNav } from "@/components/layout/BottomNav";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const KeypadPage = () => {
  const { amount, formatAmount } = usePayment();
  const { activeReader } = useDevice();
  const navigate = useNavigate();
  
  const numericAmount = parseFloat(amount) || 0;
  const isValidAmount = numericAmount > 0;
  
  const handleCharge = () => {
    if (!activeReader) {
      toast.error("No card reader connected. Please connect a reader in the profile section.");
      return;
    }
    
    if (!isValidAmount) {
      toast.error("Please enter a valid amount");
      return;
    }
    
    navigate("/process-payment");
  };
  
  return (
    <div className="min-h-screen flex flex-col pb-16 bg-background">
      <div className="flex-1 flex flex-col px-4 pt-8">
        <div className="flex-1 flex flex-col items-center justify-center mb-8">
          <div className="text-muted-foreground text-sm mb-2">Amount</div>
          <div className="flex items-baseline">
            <span className="text-2xl mr-2">₦</span>
            <div className={cn(
              "payment-amount",
              !amount && "text-muted-foreground"
            )}>
              {formatAmount(amount)}
            </div>
          </div>
        </div>
        
        <div className="w-full max-w-md mx-auto mb-6">
          <Keypad />
        </div>
        
        <div className="w-full max-w-md mx-auto mb-8">
          <Button 
            onClick={handleCharge} 
            disabled={!isValidAmount}
            className="w-full h-14 text-lg relative overflow-hidden group"
          >
            <span className="absolute inset-0 flex items-center justify-center group-hover:translate-y-10 transition-transform duration-200">
              Charge ₦{formatAmount(amount)}
            </span>
            <span className="absolute inset-0 flex items-center justify-center -translate-y-10 group-hover:translate-y-0 transition-transform duration-200">
              <ArrowRight className="h-6 w-6" />
            </span>
          </Button>
        </div>
      </div>
      
      <BottomNav />
    </div>
  );
};

export default KeypadPage;
