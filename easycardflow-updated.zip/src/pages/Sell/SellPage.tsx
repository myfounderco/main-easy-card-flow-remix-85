import React from "react";
import "./SellPage.css";

const SellPage: React.FC = () => {
  const handleButtonClick = (value: string) => {
    console.log("Keypad button pressed:", value);
  };

  return (
    <div className="sell-page">
      <div className="top-bar">
        <div className="profile-icon">👤</div>
      </div>
      <h2>Sell Page</h2>
      <div className="keypad">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
          <button key={num} onClick={() => handleButtonClick(num.toString())}>
            {num}
          </button>
        ))}
        <button onClick={() => handleButtonClick("0")}>0</button>
        <button onClick={() => handleButtonClick("+")}>+</button>
      </div>
    </div>
  );
};

export default SellPage;
