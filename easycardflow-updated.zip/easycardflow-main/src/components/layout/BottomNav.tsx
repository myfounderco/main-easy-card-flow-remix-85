
import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { 
  ShoppingBag, 
  History, 
  UserCircle 
} from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const [activePath, setActivePath] = useState("");
  
  useEffect(() => {
    setActivePath(location.pathname);
  }, [location]);
  
  const navItems = [
    {
      name: "Sell",
      icon: <ShoppingBag className="h-6 w-6" />,
      path: "/"
    },
    {
      name: "History",
      icon: <History className="h-6 w-6" />,
      path: "/history"
    },
    {
      name: "Profile",
      icon: <UserCircle className="h-6 w-6" />,
      path: "/profile"
    }
  ];
  
  const handleNavigation = (path: string) => {
    navigate(path);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-background border-t border-border shadow-sm z-50">
      <div className="grid grid-cols-3 h-full">
        {navItems.map((item) => (
          <button 
            key={item.path}
            onClick={() => handleNavigation(item.path)}
            className="flex flex-col items-center justify-center transition-colors duration-200"
          >
            <div className={cn(
              "flex flex-col items-center justify-center transition-all duration-300",
              activePath === item.path ? "text-primary scale-105" : "text-muted-foreground"
            )}>
              {item.icon}
              <span className="text-xs mt-1">{item.name}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

export default BottomNav;
