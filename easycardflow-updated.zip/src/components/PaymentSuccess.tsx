import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import axios from "axios";

const PaymentSuccess: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [paymentInfo, setPaymentInfo] = useState<any>(null);
  const reference = searchParams.get("reference");

  useEffect(() => {
    if (reference) {
      axios.get(\`/api/paystack/verify/\${reference}\`).then((res) => {
        setPaymentInfo(res.data);
      }).catch((error) => {
        console.error("Payment verification failed:", error);
      });
    }
  }, [reference]);

  return (
    <div>
      <h2>Payment Successful!</h2>
      {paymentInfo && <pre>{JSON.stringify(paymentInfo, null, 2)}</pre>}
    </div>
  );
};

export default PaymentSuccess;
