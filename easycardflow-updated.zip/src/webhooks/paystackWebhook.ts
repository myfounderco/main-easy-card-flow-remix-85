import express from "express";
import crypto from "crypto";

const router = express.Router();

const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY || "";

/**
 * Webhook endpoint to handle Paystack payment events.
 */
router.post("/paystack-webhook", express.json({ type: "application/json" }), (req, res) => {
  const secret = PAYSTACK_SECRET_KEY;
  const hash = crypto.createHmac("sha512", secret).update(JSON.stringify(req.body)).digest("hex");

  if (hash !== req.headers["x-paystack-signature"]) {
    return res.status(401).json({ error: "Invalid signature" });
  }

  const event = req.body;
  console.log("Received Paystack event:", event);

  if (event.event === "charge.success") {
    // Handle successful payment (e.g., update database, send email)
    console.log("Payment successful for:", event.data.reference);
  }

  res.status(200).send("Webhook received");
});

export default router;
