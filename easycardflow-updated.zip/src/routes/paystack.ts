import express from "express";
import { initializePayment, verifyPayment } from "../services/paystack";

const router = express.Router();

router.post("/initiate", async (req, res) => {
  try {
    const { email, amount } = req.body;
    const data = await initializePayment(email, amount);
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: "Payment initialization failed" });
  }
});

router.get("/verify/:reference", async (req, res) => {
  try {
    const reference = req.params.reference;
    const data = await verifyPayment(reference);
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: "Payment verification failed" });
  }
});

export default router;
