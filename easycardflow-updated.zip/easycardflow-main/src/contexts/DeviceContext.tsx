
import React, { createContext, useContext, useState, useEffect } from "react";
import { toast } from "sonner";

interface CardReader {
  id: string;
  name: string;
  connected: boolean;
  batteryLevel?: number;
  lastConnected?: Date;
}

interface BankAccount {
  id: string;
  bankName: string;
  accountName: string;
  accountNumber: string;
  isDefault: boolean;
}

interface DeviceContextType {
  readers: CardReader[];
  activeReader: CardReader | null;
  connectReader: (readerId: string) => Promise<boolean>;
  disconnectReader: (readerId: string) => void;
  addReader: (reader: Omit<CardReader, "id" | "connected">) => CardReader;
  bankAccounts: BankAccount[];
  addBankAccount: (account: Omit<BankAccount, "id">) => void;
  removeBankAccount: (accountId: string) => void;
  setDefaultBankAccount: (accountId: string) => void;
}

const DeviceContext = createContext<DeviceContextType | undefined>(undefined);

export const DeviceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [readers, setReaders] = useState<CardReader[]>([
    {
      id: "reader-001",
      name: "Square Reader S1",
      connected: false,
      batteryLevel: 85,
      lastConnected: new Date(Date.now() - 86400000) // 1 day ago
    }
  ]);
  
  const [activeReader, setActiveReader] = useState<CardReader | null>(null);
  
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedReaders = localStorage.getItem("cardReaders");
    const savedAccounts = localStorage.getItem("bankAccounts");
    const savedActiveReader = localStorage.getItem("activeReader");
    
    if (savedReaders) {
      try {
        const parsedReaders = JSON.parse(savedReaders);
        // Convert date strings back to Date objects
        const formattedReaders = parsedReaders.map((r: any) => ({
          ...r,
          lastConnected: r.lastConnected ? new Date(r.lastConnected) : undefined
        }));
        setReaders(formattedReaders);
      } catch (error) {
        console.error("Error parsing card readers from localStorage:", error);
      }
    }
    
    if (savedAccounts) {
      try {
        setBankAccounts(JSON.parse(savedAccounts));
      } catch (error) {
        console.error("Error parsing bank accounts from localStorage:", error);
      }
    }
    
    if (savedActiveReader) {
      try {
        const reader = JSON.parse(savedActiveReader);
        if (reader) {
          setActiveReader({
            ...reader,
            lastConnected: reader.lastConnected ? new Date(reader.lastConnected) : undefined
          });
        }
      } catch (error) {
        console.error("Error parsing active reader from localStorage:", error);
      }
    }
  }, []);

  // Save data to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("cardReaders", JSON.stringify(readers));
  }, [readers]);
  
  useEffect(() => {
    localStorage.setItem("bankAccounts", JSON.stringify(bankAccounts));
  }, [bankAccounts]);
  
  useEffect(() => {
    if (activeReader) {
      localStorage.setItem("activeReader", JSON.stringify(activeReader));
    } else {
      localStorage.removeItem("activeReader");
    }
  }, [activeReader]);

  const connectReader = async (readerId: string): Promise<boolean> => {
    // Simulate connecting to a card reader
    return new Promise((resolve) => {
      setTimeout(() => {
        setReaders(prevReaders => 
          prevReaders.map(reader => 
            reader.id === readerId 
              ? { ...reader, connected: true, lastConnected: new Date() } 
              : reader
          )
        );
        
        const reader = readers.find(r => r.id === readerId);
        if (reader) {
          const updatedReader = { ...reader, connected: true, lastConnected: new Date() };
          setActiveReader(updatedReader);
          toast.success(`Connected to ${reader.name}`);
        }
        
        resolve(true);
      }, 2000);
    });
  };

  const disconnectReader = (readerId: string) => {
    setReaders(prevReaders => 
      prevReaders.map(reader => 
        reader.id === readerId 
          ? { ...reader, connected: false } 
          : reader
      )
    );
    
    if (activeReader?.id === readerId) {
      setActiveReader(null);
    }
    
    const reader = readers.find(r => r.id === readerId);
    if (reader) {
      toast.info(`Disconnected from ${reader.name}`);
    }
  };

  const addReader = (reader: Omit<CardReader, "id" | "connected">): CardReader => {
    const newReader = {
      ...reader,
      id: `reader-${Date.now().toString(36)}`,
      connected: false
    };
    
    setReaders(prev => [...prev, newReader]);
    return newReader;
  };

  const addBankAccount = (account: Omit<BankAccount, "id">) => {
    const newAccount = {
      ...account,
      id: `account-${Date.now().toString(36)}`
    };
    
    // If this is the first account or it's set as default, ensure it's the only default
    if (account.isDefault || bankAccounts.length === 0) {
      setBankAccounts(prev => [
        ...prev.map(acc => ({ ...acc, isDefault: false })),
        newAccount
      ]);
    } else {
      setBankAccounts(prev => [...prev, newAccount]);
    }
    
    toast.success(`Bank account added: ${account.bankName}`);
  };

  const removeBankAccount = (accountId: string) => {
    const accountToRemove = bankAccounts.find(acc => acc.id === accountId);
    
    setBankAccounts(prev => {
      const filtered = prev.filter(acc => acc.id !== accountId);
      
      // If we removed the default account and there are other accounts,
      // make the first one the default
      if (accountToRemove?.isDefault && filtered.length > 0) {
        return [
          { ...filtered[0], isDefault: true },
          ...filtered.slice(1)
        ];
      }
      
      return filtered;
    });
    
    if (accountToRemove) {
      toast.info(`Bank account removed: ${accountToRemove.bankName}`);
    }
  };

  const setDefaultBankAccount = (accountId: string) => {
    setBankAccounts(prev => 
      prev.map(account => ({
        ...account,
        isDefault: account.id === accountId
      }))
    );
    
    const account = bankAccounts.find(acc => acc.id === accountId);
    if (account) {
      toast.success(`${account.bankName} set as default account`);
    }
  };

  return (
    <DeviceContext.Provider
      value={{
        readers,
        activeReader,
        connectReader,
        disconnectReader,
        addReader,
        bankAccounts,
        addBankAccount,
        removeBankAccount,
        setDefaultBankAccount
      }}
    >
      {children}
    </DeviceContext.Provider>
  );
};

export const useDevice = (): DeviceContextType => {
  const context = useContext(DeviceContext);
  if (context === undefined) {
    throw new Error("useDevice must be used within a DeviceProvider");
  }
  return context;
};
